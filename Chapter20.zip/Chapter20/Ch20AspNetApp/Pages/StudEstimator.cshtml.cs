using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.ComponentModel.DataAnnotations;

namespace MyApp.Namespace
{
    public class StudEstimatorModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage = "Wall length is required.")]
        [Range(1, 100, ErrorMessage = "Wall length must be between 1 and 100 feet.")]
        public decimal? WallLength { get; set; }  // in feet

        [BindProperty]
        [Required(ErrorMessage = "Wall height is required.")]
        [Range(1, 20, ErrorMessage = "Wall height must be between 1 and 20 feet.")]
        public decimal? WallHeight { get; set; }  // in feet

        [BindProperty]
        [Required(ErrorMessage = "Stud spacing is required.")]
        public int? StudSpacing { get; set; }     // in inches

        public int? EstimatedStudCount { get; private set; }

        public string? ResultMessage { get; private set; }

        public void OnGet()
        {
            // Runs when the page loads for the first time.
        }

        public void OnPost()
        {
            if (!ModelState.IsValid)
            {
                ResultMessage = "Please correct the errors and try again.";
                return;
            }

            // Additional domain rule: only allow 16 or 24 inch spacing.
            if (StudSpacing != 16 && StudSpacing != 24)
            {
                ResultMessage = "Please choose a valid stud spacing option.";
                return;
            }

            // Convert wall length from feet to inches.
            decimal wallLengthInches = WallLength!.Value * 12m;

            // Calculate how many studs are needed along the wall length.
            decimal rawStudCount = Math.Floor(wallLengthInches / StudSpacing.Value) + 1;

            // Round up to the nearest whole number.
            EstimatedStudCount = (int)Math.Ceiling(rawStudCount);

            ResultMessage = $"Estimated studs needed: {EstimatedStudCount}";
        }

    }

}

